/* 
 * Operating Systems  (2INCO)  Practical Assignment
 * Interprocess Communication
 *
 * Kajetan Knopp (1674404)
 * Kasra Gheytuli (1753665)
 *
 * Grading:
 * Your work will be evaluated based on the following criteria:
 * - Satisfaction of all the specifications
 * - Correctness of the program
 * - Coding style
 * - Report quality
 * - Deadlock analysis
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>    
#include <unistd.h>    // for execlp
#include <mqueue.h>    // for mq


#include "settings.h"  
#include "messages.h"

char client2dealer_name[20] = "/client2dealer";
char dealer2worker1_name[20] = "/dealer2worker1";
char dealer2worker2_name[20] = "/dealer2worker2";
char worker2dealer_name[20] = "/worker2dealer";

int main (int argc, char * argv[])
{
  if (argc != 1)
  {
    fprintf (stderr, "%s: invalid arguments\n", argv[0]);
  }
  
  // TODO:
    //  * create the message queues (see message_queue_test() in
    //    interprocess_basic.c)
    //  * read requests from the Req queue and transfer them to the workers
    //    with the Sx queues
    //  * read answers from workers in the Rep queue and print them
    //  * wait until the client has been stopped (see process_test())
    //  * clean up the message queues (see message_queue_test())

    // Important notice: make sure that the names of the message queues
    // contain your goup number (to ensure uniqueness during testing)


  // Defining the number of workers for S1 and S2
  int S1_workers = N_SERV1;
  int S2_workers = N_SERV2;

  // Creating the message queues
  mqd_t Req_queue_KasraKai_24;
  mqd_t Rsp_queue_KasraKai_24;
  mqd_t S1_queue_KasraKai_24;
  mqd_t S2_queue_KasraKai_24;

  // Creating the messages
  MQ_REQUEST_MESSAGE  req;
  MQ_RESPONSE_MESSAGE rsp;

  
  // Defining the attributes
  struct mq_attr      attr;
  attr.mq_maxmsg = MQ_MAX_MESSAGES;

  // Creating the processes
  pid_t processID;

  // Defining the PID's of the processes
  pid_t clientPID;
  pid_t service1PID;
  pid_t service2PID;
  pid_t dealerPID;

  // Creating the message queues

  // Creating the request queue
  attr.mq_msgsize = sizeof (MQ_REQUEST_MESSAGE);
  Req_queue_KasraKai_24 = mq_open(client2dealer_name, O_RDWR | O_CREAT | O_EXCL, 0600, &attr);

  // Creating the response queue
  attr.mq_msgsize = sizeof (MQ_RESPONSE_MESSAGE);
  Rsp_queue_KasraKai_24 = mq_open(worker2dealer_name, O_RDWR | O_CREAT | O_EXCL, 0600, &attr);

  // Creating the Service 1 queue
  attr.mq_msgsize = sizeof (MQ_SERVICE_1_MESSAGE);
  S1_queue_KasraKai_24 = mq_open(dealer2worker1_name, O_RDWR | O_CREAT | O_EXCL, 0600, &attr);

  // Creating the Service 2 queue
  attr.mq_msgsize = sizeof (MQ_SERVICE_2_MESSAGE);
  S2_queue_KasraKai_24 = mq_open(dealer2worker2_name, O_RDWR | O_CREAT | O_EXCL, 0600, &attr);

  /* 
    Creating the client process;
      client: processID = 0
      router: processID = client
  */
  processID = fork();

  // -> router process
  if(processID > 0) {
    // We know that processID for the router currently holds the client processID, so we save it
    clientPID = processID;

    /* 
      Creating the Service 1 process;
        Service 1: processID = 0
        router: processID = service_1
    */ 
    processID = fork();

    // -> service 1 process
    if(processID == 0){
      // Create the correct number of workers for S1
      for(int i = 0; i < S1_workers; i++){
        // Create new process
        processID = fork();
        // Exit the loop if the process is a child; only fork from the initial worker 1 process
        if(processID == 0){
          break;
        }
      }

      // -> worker (doing jobs)
      if(processID == 0 && S1_workers > 0){
        execlp ("./worker_s1", "read_queue", dealer2worker1_name, "write_queue", worker2dealer_name, NULL);
      }

      // -> parent worker
      // Wait for all of the workers to be finished
      while(wait(NULL) > 0);
      return 0;
    }
    // -> router process
    else {
      // We know that processID for the router currently holds the Service 1 processID, so we save it
      service1PID = processID;

      /* 
        Creating the Service 2 process;
          Service 2: processID = 0
          router: processID = service_2
      */ 
      processID = fork();

      // -> service 2 process
      if(processID == 0){
        // Create the correct number of workers for S2
        for(int i = 0; i < S2_workers; i++){
          // Create new process
          processID = fork();
          // Exit the loop if the process is a child; only fork from the initial worker 1 process
          if(processID == 0){
            break;
          }
        }
        
        // -> worker (doing jobs)
        if(processID == 0 && S2_workers > 0){
          // TODO:
          execlp ("./worker_s2", "read_queue", dealer2worker2_name, "write_queue", worker2dealer_name, NULL);
        }

        // -> parent worker
        // Wait for all of the workers to be finished
        while(wait(NULL) > 0);
        return 0;
      }
      // -> router process
      else {
        // We know that processID for the router currently holds the Service 2 processID, so we save it
        service2PID = processID;

        // Final fork to create the dealer process
        /*
          Creating the dealer process;
            dealer: processID = 0
            router: processID = dealer
        */
        processID = fork();

        // -> dealer process
        if(processID == 0){
          // Using the request queue, send the requests to the workers
          while(mq_receive(Req_queue_KasraKai_24, (char*) &req, sizeof(req), NULL) != -1){
            // Check if the request is for Service 1
            if(req.Service_ID == 1){
              MQ_SERVICE_1_MESSAGE s1;
              // Create a new Service 1 message
              s1.Request_ID = req.Request_ID;
              s1.data = req.data;

              // Send the request to the Service 1 queue
              if(mq_send(S1_queue_KasraKai_24, (char*) &s1, sizeof(s1), 0) == -1){
                perror("mq_send Service 1");
                exit(EXIT_FAILURE);
              }
            }
            
            // Check if the request is for Service 2
            else if(req.Service_ID == 2){
              // Create a new Service 2 message
              MQ_SERVICE_2_MESSAGE s2;
              s2.Request_ID = req.Request_ID;
              s2.data = req.data;

              // Send the request to the Service 2 queue
              if(mq_send(S2_queue_KasraKai_24, (char*) &s2, sizeof(s2), 0) == -1){
                perror("mq_send Service 2");
                exit(EXIT_FAILURE);
              }
            }

            // Else final message has been sent, so we break out of the loop
            else if(req.Service_ID == -1 && req.Request_ID == -1 && req.data == -1){
              // Send a final message to Worker 1
              MQ_SERVICE_1_MESSAGE s1;
              s1.Request_ID = -1;
              s1.data = -1;

              // Send the request to the Service 1 queue
              for(int i = 0; i < S1_workers; i++){
                if(mq_send(S1_queue_KasraKai_24, (char*) &s1, sizeof(s1), 0) == -1){
                  perror("mq_send Service 1");
                  exit(EXIT_FAILURE);
                }
              }
              
              // Send a final message to Worker 2
              MQ_SERVICE_2_MESSAGE s2;
              s2.Request_ID = -1;
              s2.data = -1;

              // Send the request to the Service 2 queue
              for(int i = 0; i < S2_workers; i++){
                if(mq_send(S2_queue_KasraKai_24, (char*) &s2, sizeof(s2), 0) == -1){
                  perror("mq_send Service 2");
                  exit(EXIT_FAILURE);
                }
              }
              break;
            }
          }

          return 0;
        }
        // -> router process
        else{
          int final_message_s1 = 0;
          int final_message_s2 = 0;
          // We know that processID for the router currently holds the dealer processID, so we save it
          dealerPID = processID;

          // Using the response queue, print the responses from the workers
          while(mq_receive(Rsp_queue_KasraKai_24, (char*) &rsp, sizeof(rsp), NULL) != -1){
            // Check if the message is the final message for each of the workers
            if(rsp.Request_ID == -1 && rsp.result == -1){
              final_message_s1++;
            } else if(rsp.Request_ID == -2 && rsp.result == -2) {
              final_message_s2++;
            } else{
              printf("%d -> %d\n", rsp.Request_ID, rsp.result);
            }

            // Finish execution in case bpoth workers sent a final message
            if(final_message_s1 >= N_SERV1 && final_message_s2 >= N_SERV2){
              break;
            }
          }
          // Wait for the dealer process to be finished
          waitpid(dealerPID, NULL, 0);

          // Release resources for the children processes
          waitpid(clientPID, NULL, 0);
          waitpid(service1PID, NULL, 0);
          waitpid(service2PID, NULL, 0);

          // Close the message queues
          mq_close(Req_queue_KasraKai_24);
          mq_close(Rsp_queue_KasraKai_24);
          mq_close(S1_queue_KasraKai_24);
          mq_close(S2_queue_KasraKai_24);

          // Unlink the message queues
          mq_unlink(client2dealer_name);
          mq_unlink(worker2dealer_name);
          mq_unlink(dealer2worker1_name);
          mq_unlink(dealer2worker2_name);
        }
      }
    }
  } 
  // -> client process
  else {
    // TODO:
    execlp ("./client", "queue", client2dealer_name, NULL);
  }


  return (0);
}
