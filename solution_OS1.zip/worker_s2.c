/* 
 * Operating Systems  (2INCO)  Practical Assignment
 * Interprocess Communication
 *
 * Kajetan Knopp (1674404)
 * Kasra Gheytuli (1753665)
 *
 * Grading:
 * Your work will be evaluated based on the following criteria:
 * - Satisfaction of all the specifications
 * - Correctness of the program
 * - Coding style
 * - Report quality
 * - Deadlock analysis
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>      // for perror()
#include <unistd.h>     // for getpid()
#include <mqueue.h>     // for mq-stuff
#include <time.h>       // for time()

#include "messages.h"
#include "service2.h"

static void rsleep (int t);

char* name = "NO_NAME_DEFINED";
mqd_t dealer2worker;
mqd_t worker2dealer;


int main (int argc, char * argv[])
{
    /* ----------------------------------------------------
       ---------------  Parsing arguments ----------------- 
       ---------------------------------------------------- */
    // Get the name of the worker queue, with the name provided under argument read_queue
    char* read_queue = argv[1];

    // Get the name of the response queue, with the name provided under argument write_queue
    char* write_queue = argv[3];


    /* ----------------------------------------------------
       ------------------  Request queue ------------------ 
       ---------------------------------------------------- */
    // Open the read queue
    mqd_t worker = mq_open(read_queue, O_RDONLY);

    // Check if the read queue was opened successfully
    if (worker == -1)
    {
        perror("mq_open Worker 1");
        exit(EXIT_FAILURE);
    }


    /* ----------------------------------------------------
       -----------------  Response queue ------------------ 
       ---------------------------------------------------- */
    // Open the write queue
    mqd_t response = mq_open(write_queue, O_WRONLY);

    // Check if the write queue was opened successfully
    if (response == -1)
    {
        perror("mq_open Response queue for worker 1");
        exit(EXIT_FAILURE);
    }


    /* ----------------------------------------------------
       -----------------  Doing requests ------------------ 
       ---------------------------------------------------- */
    // Create a new service 2 message
    MQ_SERVICE_2_MESSAGE s2;

    // While we can read from the read queue
    while (mq_receive(worker, (char*) &s2, sizeof(s2), NULL) != -1)
    {
        // Create a response message
        MQ_RESPONSE_MESSAGE response_message;

        // Check if the message is the final message
        if (s2.Request_ID == -1 && s2.data == -1)
        {
            response_message.Request_ID = -2;
            response_message.result = -2;
            if (mq_send(response, (char*) &response_message, sizeof(response_message), 0) == -1)
            {
                perror("mq_send Writing final response from worker 2");
                exit(EXIT_FAILURE);
            }
            // Break out of the loop
            break;
        }

        // Do the job
        response_message.Request_ID = s2.Request_ID;
        response_message.result = service(s2.data);

        // Sleep as defined in the task
        rsleep(10000);

        // Write the results to the response queue
        if (mq_send(response, (char*) &response_message, sizeof(response_message), 0) == -1)
        {
            perror("mq_send Writing response from worker 2");
            exit(EXIT_FAILURE);
        }
    }


    /* ----------------------------------------------------
       ----------------  Ending operation ----------------- 
       ---------------------------------------------------- */
    // Close the read and write queues
    if (mq_close(worker) == -1)
    {
        perror("mq_close Worker 2");
        exit(EXIT_FAILURE);
    }
    if (mq_close(response) == -1)
    {
        perror("mq_close Response queue for worker 2");
        exit(EXIT_FAILURE);
    }

    return(0);
}

/*
 * rsleep(int t)
 *
 * The calling thread will be suspended for a random amount of time
 * between 0 and t microseconds
 * At the first call, the random generator is seeded with the current time
 */
static void rsleep (int t)
{
    static bool first_call = true;
    
    if (first_call == true)
    {
        srandom (time (NULL) % getpid ());
        first_call = false;
    }
    usleep (random() % t);
}
